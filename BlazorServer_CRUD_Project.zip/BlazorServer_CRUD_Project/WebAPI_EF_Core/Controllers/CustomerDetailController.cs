﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using WebAPI_EF_Core.Context;
using WebAPI_EF_Core.Model;

namespace WebAPI_EF_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerDetailController : ControllerBase
    {
        private readonly CustomerAPIDbContext _CustomerAPIDbContext;
        public CustomerDetailController(CustomerAPIDbContext contactsAPIDbContext)
        {
            _CustomerAPIDbContext = contactsAPIDbContext;

        }
        [HttpGet("GetAllCustomer")]
        public async Task<IActionResult> GetAllCustomer()
        {
            var lst = await _CustomerAPIDbContext.Customers.ToListAsync();
            return Ok(lst);
        }
        [HttpPost]
        [Route("AddCustomer")]
        public async Task<bool> AddCustomer(Customer customer)
        {
            if (customer != null)
            {
                await _CustomerAPIDbContext.Customers.AddAsync(customer);
                await _CustomerAPIDbContext.SaveChangesAsync();
                return true;
            }
            else
            {
                return false;
            }

        }
        [HttpGet]
        [Route("GetCustomerById/{id}")]
        public async Task<IActionResult> GetCustomerById(int id)
        {
            var GetCustomer = await _CustomerAPIDbContext.Customers.FindAsync(id);
            return Ok(GetCustomer);
        }

        [HttpPut("UpdateCustomer/{id}")]
        public async Task<IActionResult> UpdateCustomer(int id, [FromBody] Customer updatedCustomer)
        {
            var existingCustomer = await _CustomerAPIDbContext.Customers.FindAsync(id);

            if (existingCustomer == null)
                return NotFound($"Customer with ID {id} not found.");

            existingCustomer.EmployeName = updatedCustomer.EmployeName;
            existingCustomer.Designation = updatedCustomer.Designation;
            existingCustomer.Gender = updatedCustomer.Gender;
            existingCustomer.City = updatedCustomer.City;
            
            await _CustomerAPIDbContext.SaveChangesAsync();

            return Ok(true);
        }

        [HttpDelete]
        [Route("DeleteCustomer/{id}")]
        public async Task<IActionResult> DeleteCustomer(int id)
        {
            var data = await _CustomerAPIDbContext.Customers.FindAsync(id);
            if (data == null)
            {
                return NotFound($"Customer Id is {id} not found");
            }
            else
            {
                _CustomerAPIDbContext.Customers.Remove(data);
                await _CustomerAPIDbContext.SaveChangesAsync();
                return Ok(true);
            }
           
        }

    }
}
