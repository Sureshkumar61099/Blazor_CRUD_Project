﻿using Microsoft.EntityFrameworkCore;
using WebAPI_EF_Core.Model;

namespace WebAPI_EF_Core.Context
{
    public class CustomerAPIDbContext : DbContext
    {
        public CustomerAPIDbContext(DbContextOptions options):base(options) {
        
        }
        

        public DbSet<Customer> Customers { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.ToTable("Customers"); // Name of the SQL table

                entity.HasKey(e => e.Id);

                entity.Property(e => e.EmployeName)
                      .HasMaxLength(100)
                      .IsRequired(false); // You can make it true if you want it NOT NULL

                entity.Property(e => e.Gender)
                      .HasMaxLength(10);

                entity.Property(e => e.City)
                      .HasMaxLength(50);

                entity.Property(e => e.Designation)
                      .HasMaxLength(100);
            });
        }
    }
}
