﻿

namespace Blazor_Sample_CRUD.Data
{
    public class SampleEmployee
    {
       
        public int Id { get; set; }
       
        public string EmployeName { get; set; }
      
        public string Gender { get; set; }
      
        public string City { get; set; }
       
        public string Designation { get; set; }
    }
}
