﻿using Blazor_Sample_CRUD.Data;


using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace Blazor_Sample_CRUD.Repository
{
    public class EmployeeServices
    {
        #region Property

        private readonly HttpClient _httpClient;
        #endregion

        #region Constructor
        public EmployeeServices(HttpClient httpClient)
        {

            _httpClient = httpClient;
        }
        #endregion

        #region Get List of Employees
        public async Task<List<SampleEmployee>> GetAllEmployeesAsync()
        
        {
            var emplist = await _httpClient.GetFromJsonAsync<List<SampleEmployee>>("/api/CustomerDetail/GetAllCustomer");
            return emplist;
        }
        #endregion

        #region Insert Employee
        public async Task<bool> InsertEmployeeAsync(SampleEmployee employee)
        {
            var response = await _httpClient.PostAsJsonAsync("/api/CustomerDetail/AddCustomer", employee);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<bool>();
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Get Employee by Id
        public async Task<SampleEmployee> GetEmployeeAsync(int Id)
        {
            var response = await _httpClient.GetFromJsonAsync<SampleEmployee>($"/api/CustomerDetail/GetCustomerById/{Id}");
            return response;
        }
        #endregion

        #region Update Employee
        public async Task<bool> UpdateEmployeeAsync(int id , SampleEmployee employee)
        {
            var response = await _httpClient.PutAsJsonAsync($"/api/CustomerDetail/UpdateCustomer/{id}",employee);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<bool>();
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region DeleteEmployee
        public async Task<bool> DeleteEmployeeAsync(int Id)
        {
            var response = await _httpClient.DeleteAsync($"/api/CustomerDetail/DeleteCustomer/{Id}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<bool>();
            }
            else
            {
                return false;
            }
            
        }
        #endregion
    }
}
